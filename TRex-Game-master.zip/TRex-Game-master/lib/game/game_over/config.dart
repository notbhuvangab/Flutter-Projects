class GameOverConfig {
  static double textWidth = 382.0;
  static double textHeight = 22.0;
  static double restartWidth = 72.0;
  static double restartHeight = 64.0;
}
