class ObstacleConfig {
  static int maxObstacleLength = 3;
  static double maxGapCoefficient = 1.5;
}
