 # Trex game Flutter edition
 <img alt="Awesome Flutter" src="https://img.shields.io/badge/Awesome-Flutter-blue.svg?longCache=true&style=flat-square" />


##  Preview of The App

![alt img](https://miro.medium.com/max/370/1*BoO4YXf6zYI45BIWEhd7BQ.gif)
