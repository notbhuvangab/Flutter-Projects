package com.example.canteen_food_ordering_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
